export const firebaseConfig = {
  "projectId": "studio-3301259230-2093f",
  "appId": "1:840757376042:web:dc9cadded4da0e60b7ff53",
  "apiKey": "AIzaSyB46aAGNIQFLhr5fWt-JA_lalHfmHpxlSo",
  "authDomain": "studio-3301259230-2093f.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "840757376042"
};
